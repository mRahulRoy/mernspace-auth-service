This is an auth service built using different tech stacks, and its in under development right now and also a part of our microservices application .
